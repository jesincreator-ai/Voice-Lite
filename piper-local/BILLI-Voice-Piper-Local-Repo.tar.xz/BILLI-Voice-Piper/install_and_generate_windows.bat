@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher not found. Install Python 3.11 from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3.11 -m venv .venv
  if errorlevel 1 goto :failed
)
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :failed
.venv\Scripts\python.exe -m host.generate_voice_clips --languages all --modes all
if errorlevel 1 goto :failed
echo.
echo Generated English, Tamil and Sinhala Standard/Rugged WAV clips.
echo Copy build\voice_clips\en, ta and si into the SD card's billi_voice folder.
pause
exit /b 0
:failed
echo.
echo Setup or generation failed. Read the error above and docs\PC_SETUP.md.
pause
exit /b 1
