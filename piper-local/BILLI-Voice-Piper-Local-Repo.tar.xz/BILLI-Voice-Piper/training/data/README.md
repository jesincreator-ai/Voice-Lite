# Private training data

Create one subfolder per language and speaker. Add `speaker_consent.txt`, `metadata.csv`, and a `wavs/` folder. Keep raw recordings and any personal consent documents private; they are excluded from the Git archive by `.gitignore` patterns where possible. Use the validator before preparing any Piper training run.
